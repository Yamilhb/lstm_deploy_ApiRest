import joblib
from sklearn.pipeline import Pipeline
from lstm_model.config.core import TRAINED_MODEL_DIR


def load_pipeline(*, file_name: str) -> Pipeline:
    """Load a persisted pipeline."""

    file_path = TRAINED_MODEL_DIR / file_name
    trained_model = joblib.load(filename=file_path)
    return trained_model